package ru.mirea.gibo0118.salina;

public class TestDog {
    public static void main(String[] args) {
        Dog d1 = new Dog(52.5, "labrador");
        System.out.println(d1);
        d1.setBreed("spitz");
        d1.setHeight(20.5);
        System.out.println(d1);
    }
}

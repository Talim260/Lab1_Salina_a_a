package ru.mirea.gibo0118.salina;

public class TestBall {
    public static void main(String[] args) {
        Ball b1 = new Ball(20.5,"red");
        System.out.println(b1);
        b1.setColor("green");
        b1.setRadius(20.5);
        System.out.println(b1);
    }
}

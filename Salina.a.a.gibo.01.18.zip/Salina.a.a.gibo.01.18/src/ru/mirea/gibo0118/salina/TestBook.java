package ru.mirea.gibo0118.salina;

public class TestBook {
    public static void main(String[] args) {
        Book b1 = new Book(300.0, "AnnaKarenina");
        System.out.println(b1);
        b1.setName("Faust");
        b1.setNumber_of_pages(250.0);
        System.out.println(b1);
    }
}

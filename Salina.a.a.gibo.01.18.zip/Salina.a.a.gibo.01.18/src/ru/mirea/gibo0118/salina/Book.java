package ru.mirea.gibo0118.salina;
import java.lang.*;
public class Book {
    private double number_of_pages;
    private String name;

    public Book(double number_of_pages, String name) {
        this.number_of_pages = number_of_pages;
        this.name = name;
    }

    public Book(double number_of_pages) {
        this.number_of_pages = number_of_pages;
    }

    public double getNumber_of_pages() {
        return number_of_pages;
    }

    public void setNumber_of_pages(double number_of_pages) {
        this.number_of_pages = number_of_pages;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Book{" +
                "number_of_pages=" + number_of_pages +
                ", name='" + name + '\'' +
                '}';
    }
}

package ru.mirea.gibo0118.salina;
import java.lang.*;

public class Dog {
    private double height;
    private String breed;


    public Dog(double height, String breed) {
        this.height = height;
        this.breed = breed;
    }

    public Dog(double height) {
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "height=" + height +
                ", breed='" + breed + '\'' +
                '}';
    }
}

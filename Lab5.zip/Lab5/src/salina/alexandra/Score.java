package salina.alexandra;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Score {
    private static int first;
    private static int second;

    public static void main(String[] args) {
        JFrame fr1 = new JFrame("Frame");
        Container cp;
        first = 0;
        second = 0;
        JButton milan, madrid;
        fr1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fr1.setSize(300, 200);
        fr1.setResizable(false);
        cp = fr1.getContentPane();
        cp.setLayout(new GridLayout(5, 1));
        milan = new JButton("AC Milan");
        madrid = new JButton("Real Madrid");
        JLabel l1 = new JLabel("Result: " + first + "X" + second);
        JLabel l2 = new JLabel("Last Scorer: " + "N/A");
        JLabel l3 = new JLabel("Winner: " + "DRAW");
        cp.add(milan);
        cp.add(madrid);
        cp.add(l1);
        cp.add(l2);
        cp.add(l3);
        milan.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                first++;
                l1.setText("Result: " + first + " X " + second);
                l2.setText("Last Scorer: " + "AC Milan");
                if(first > second)
                    l3.setText("Winner: " + "AC Milan");
                if(first == second)
                    l3.setText("Winner: " + "DRAW");
            }
        });

        madrid.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                second++;
                l1.setText("Result: " + first + " X " + second);
                l2.setText("Last Scorer: " + "Real Madrid");
                if(first < second)
                    l3.setText("Winner: " + "Real Madrid");
                if(second == first)
                    l3.setText("Winner: " + "DRAW");
            }
        });


        fr1.show();
    }
}

package salina.alexandra;

import java.io.*;
public class Main {
    public static void main(String[] args) {

        try {
            FileWriter file = new FileWriter("/Users/Александра/IdeaProjects/Лаба8/src/salina/alexanda/note.txt",false);
            String text = "Саша Салина";
            file.write(text);
            file.append('\n');
            file.append("Что-то");
            file.flush();


        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        try{
            FileReader reader = new FileReader("/Users/Александра/IdeaProjects/Лаба8/src/salina/alexanda/note.txt");
            int c;

            while((c=reader.read())!=-1){
                System.out.print((char)c);

            }
        }catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}


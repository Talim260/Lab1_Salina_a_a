package salina.alexandra;

import java.util.LinkedList;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<String> fruits = new ArrayList<String>();
        fruits.add("Вишня");
        fruits.add("Персик");

        for(String t : fruits) System.out.println(t);

        LinkedList<String> list = new LinkedList<String>();
        list.add("Турция");
        list.add("Китай");
        list.add("Австралия");
        list.addFirst("China");
        list.addLast("Англия");
        list.add(1, "Россия");
        for (int i = 0; i < list.size(); i++)
            System.out.println(list.get(i));
        list.remove(1);
        System.out.println("///////////////\n");


        if (list.contains("Китай")) System.out.println("Есть такое государство");
        list.remove(0);
        list.remove("China");

        for (String p : list) {
            System.out.println(p);

        }
        LinkedList<Person> friend = new LinkedList<Person>();
        friend.add(new Person("Victor"));
        friend.add(1, new Person("John"));
        friend.addFirst(new Person("Alex"));
        friend.addLast(new Person("Peter"));


        for(Person p : friend) System.out.println(p);
        friend.remove(1);
        for(Person p : friend) System.out.println(p);
        Person tmp = friend.getFirst();
        System.out.println(tmp);
    }
}